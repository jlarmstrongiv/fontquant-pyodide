from fontParts.base import BaseBPoint
from fontParts.fontshell.base import RBaseObject


class RBPoint(BaseBPoint, RBaseObject):
    pass
