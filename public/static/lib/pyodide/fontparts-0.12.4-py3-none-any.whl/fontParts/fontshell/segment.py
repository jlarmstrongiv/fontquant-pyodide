from fontParts.base import BaseSegment
from fontParts.fontshell.base import RBaseObject


class RSegment(BaseSegment, RBaseObject):
    pass
