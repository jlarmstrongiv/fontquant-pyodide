# -------------------
# Universal Exception
# -------------------


class FontPartsError(Exception):
    pass
