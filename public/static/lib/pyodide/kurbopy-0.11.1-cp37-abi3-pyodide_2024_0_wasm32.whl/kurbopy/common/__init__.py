from kurbopy.kurbopy import common

globals().update(common.__dict__)
